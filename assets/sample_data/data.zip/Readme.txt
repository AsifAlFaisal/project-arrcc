
The primary driving variable for "IIWBR newsletter Feb-2020.csv" file is Variety. The file is organized around "Variety" variable. For example, consider the following reported paragraph,

"Yamunanagar, Bilapsur, Sadhaura, Naraingarh and nearby areas on February 14, 2020. During the survey, the initiation of yellow rust were observed. During the survey, interactions and discussion with farmers, 
it was noticed that the farmers grown wheat varieties such as Spark (Rashi Seeds Pvt. Ltd), Barbat, HD3086, HD2967 along with wheat mixtures."

So, it is assumed that the reported variables are used in all the of reported districts

